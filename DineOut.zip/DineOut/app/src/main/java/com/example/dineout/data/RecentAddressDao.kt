package com.example.dineout.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RecentAddressDao {
    @Query("SELECT * FROM recent_addresses ORDER BY timestamp DESC LIMIT 5")
    fun getRecentAddresses(): Flow<List<RecentAddress>>

    @Insert
    suspend fun insertAddress(address: RecentAddress)

    @Query("DELETE FROM recent_addresses WHERE id NOT IN (SELECT id FROM recent_addresses ORDER BY timestamp DESC LIMIT 5)")
    suspend fun deleteOldAddresses()
} 