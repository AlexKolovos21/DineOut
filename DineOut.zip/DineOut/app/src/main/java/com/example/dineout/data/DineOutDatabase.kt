package com.example.dineout.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [Order::class, RecentAddress::class],
    version = 1
)
@TypeConverters(Converters::class)
abstract class DineOutDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun recentAddressDao(): RecentAddressDao
} 