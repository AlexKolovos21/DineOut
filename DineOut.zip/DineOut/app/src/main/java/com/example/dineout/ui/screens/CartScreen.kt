package com.example.dineout.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.dineout.R
import com.example.dineout.data.MenuItem
import com.example.dineout.data.Order
import com.example.dineout.data.Restaurant
import androidx.activity.compose.BackHandler
import java.util.UUID
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.foundation.BorderStroke
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    restaurant: Restaurant?,
    cartItems: Map<MenuItem, Int>,
    onBackClick: () -> Unit,
    onCheckoutClick: (Order) -> Unit,
    onUpdateQuantity: (MenuItem, Int) -> Unit
) {
    var orderPlaced by remember { mutableStateOf(false) }
    var currentOrder by remember { mutableStateOf<Order?>(null) }
    var deliveryAddress by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Credit Card") }
    
    // Calculate total price
    val total = cartItems.entries.sumOf { (item, quantity) -> item.price * quantity }
    
    // Apply BackHandler to prevent back navigation during order confirmation
    BackHandler(enabled = orderPlaced) {
        // Do nothing, effectively blocking back navigation when order is confirmed
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.cart)) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (orderPlaced && currentOrder != null) {
            OrderConfirmationScreen(
                order = currentOrder!!,
                onMainMenuClick = {
                    repeat(3) { onBackClick() }
                },
                modifier = Modifier.padding(padding)
            )
        } else if (cartItems.isEmpty()) {
            // Empty cart state
            EmptyCartView(
                onBackClick = onBackClick,
                modifier = Modifier.padding(padding)
            )
        } else {
            // Normal cart view with items
            CartContent(
                restaurant = restaurant,
                cartItems = cartItems,
                total = total,
                deliveryAddress = deliveryAddress, 
                onDeliveryAddressChange = { deliveryAddress = it },
                paymentMethod = paymentMethod,
                onPaymentMethodChange = { paymentMethod = it },
                onUpdateQuantity = onUpdateQuantity,
                onCheckout = {
                    if (restaurant != null) {
                        val order = Order(
                            id = UUID.randomUUID().toString(),
                            restaurantId = restaurant.id,
                            restaurantName = restaurant.name,
                            items = cartItems,
                            total = total,
                            date = System.currentTimeMillis(),
                            status = Order.STATUS_CONFIRMED,
                            deliveryAddress = deliveryAddress,
                            paymentMethod = paymentMethod
                        )
                        currentOrder = order
                        orderPlaced = true
                        onCheckoutClick(order)
                    }
                },
                modifier = Modifier.padding(padding)
            )
        }
    }
}

@Composable
fun CartContent(
    restaurant: Restaurant?,
    cartItems: Map<MenuItem, Int>,
    total: Double,
    deliveryAddress: String,
    onDeliveryAddressChange: (String) -> Unit,
    paymentMethod: String,
    onPaymentMethodChange: (String) -> Unit,
    onUpdateQuantity: (MenuItem, Int) -> Unit,
    onCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            restaurant?.let {
                Text(
                    text = it.name,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
        
        items(cartItems.entries.toList()) { (item, quantity) ->
            CartItemCard(
                item = item,
                quantity = quantity,
                onUpdateQuantity = onUpdateQuantity
            )
        }
        
        item {
            DeliveryInfoSection(
                deliveryAddress = deliveryAddress,
                onDeliveryAddressChange = onDeliveryAddressChange,
                paymentMethod = paymentMethod,
                onPaymentMethodChange = onPaymentMethodChange
            )
        }
        
        item {
            OrderSummarySection(
                cartItems = cartItems,
                total = total,
                onCheckout = onCheckout,
                deliveryAddress = deliveryAddress,
                paymentMethod = paymentMethod
            )
        }
    }
}

@Composable
fun CartItemCard(
    item: MenuItem,
    quantity: Int,
    onUpdateQuantity: (MenuItem, Int) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Item image
            item.imageUrl?.let { imageUrl ->
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(imageUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } ?: Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.name.take(2).uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Item details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$${String.format(Locale.US, "%.2f", item.price)}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            // Quantity controls
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onUpdateQuantity(item, quantity - 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = stringResource(R.string.decrease_quantity)
                    )
                }
                
                Text(
                    text = quantity.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                
                IconButton(
                    onClick = { onUpdateQuantity(item, quantity + 1) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(R.string.increase_quantity)
                    )
                }
            }
        }
    }
}

@Composable
fun DeliveryInfoSection(
    deliveryAddress: String,
    onDeliveryAddressChange: (String) -> Unit,
    paymentMethod: String,
    onPaymentMethodChange: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = stringResource(R.string.delivery_info),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        OutlinedTextField(
            value = deliveryAddress,
            onValueChange = onDeliveryAddressChange,
            label = { Text(stringResource(R.string.delivery_address)) },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null
                )
            }
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = stringResource(R.string.payment_method),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PaymentMethodButton(
                text = "Credit Card",
                isSelected = paymentMethod == "Credit Card",
                onClick = { onPaymentMethodChange("Credit Card") }
            )
            PaymentMethodButton(
                text = "Cash",
                isSelected = paymentMethod == "Cash",
                onClick = { onPaymentMethodChange("Cash") }
            )
        }
    }
}

@Composable
fun PaymentMethodButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        )
    ) {
        Text(
            text = text,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun OrderSummarySection(
    cartItems: Map<MenuItem, Int>,
    total: Double,
    onCheckout: () -> Unit,
    deliveryAddress: String,
    paymentMethod: String
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = stringResource(R.string.order_summary),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        // Subtotal
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.subtotal),
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = "$${String.format(Locale.US, "%.2f", total)}",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        
        // Delivery fee
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.delivery_fee),
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = "$2.00",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Total
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.total),
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "$${String.format(Locale.US, "%.2f", total + 2.00)}",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = onCheckout,
            modifier = Modifier.fillMaxWidth(),
            enabled = deliveryAddress.isNotBlank() && paymentMethod.isNotBlank()
        ) {
            Text(stringResource(R.string.place_order))
        }
    }
}

@Composable
fun EmptyCartView(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = stringResource(R.string.empty_cart),
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = stringResource(R.string.empty_cart_message),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(onClick = onBackClick) {
            Text(stringResource(R.string.continue_shopping))
        }
    }
}

@Composable
fun OrderConfirmationScreen(
    order: Order,
    onMainMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = stringResource(R.string.order_confirmed),
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = stringResource(R.string.order_confirmation_message),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(onClick = onMainMenuClick) {
            Text(stringResource(R.string.back_to_main_menu))
        }
    }
}

