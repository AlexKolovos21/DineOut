package com.example.dineout.data

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.Date

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }

    @TypeConverter
    fun fromString(value: String?): Map<MenuItem, Int> {
        if (value == null) return emptyMap()
        val type = object : TypeToken<Map<MenuItem, Int>>() {}.type
        return try {
            gson.fromJson<Map<MenuItem, Int>>(value, type) ?: emptyMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    @TypeConverter
    fun fromMap(map: Map<MenuItem, Int>?): String? {
        if (map == null) return null
        return gson.toJson(map)
    }
}

