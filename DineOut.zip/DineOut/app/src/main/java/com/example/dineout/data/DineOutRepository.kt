package com.example.dineout.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DineOutRepository(private val database: DineOutDatabase) {
    private val orderDao = database.orderDao()
    private val recentAddressDao = database.recentAddressDao()

    fun getAllOrders(): Flow<List<Order>> = orderDao.getAllOrders()

    suspend fun insertOrder(order: Order) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrder(order: Order) {
        orderDao.updateOrder(order)
    }

    suspend fun getOrderById(orderId: String): Order? {
        return orderDao.getOrderById(orderId)
    }

    fun getRecentAddresses(): Flow<List<String>> {
        return recentAddressDao.getRecentAddresses().map { addresses ->
            addresses.map { it.address }
        }
    }

    suspend fun addRecentAddress(address: String) {
        recentAddressDao.insertAddress(RecentAddress(address = address))
        recentAddressDao.deleteOldAddresses()
    }
} 