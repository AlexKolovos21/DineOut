package com.example.dineout.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "recent_addresses")
data class RecentAddress(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val address: String,
    val timestamp: Long = Date().time
) 