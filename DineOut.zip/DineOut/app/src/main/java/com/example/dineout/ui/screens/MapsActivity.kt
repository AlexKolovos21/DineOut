package com.example.dineout.ui.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.dineout.R
import com.example.dineout.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.util.Locale

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Language switcher
        val languageButton = findViewById<Button>(R.id.btnChangeLanguage)
        languageButton.setOnClickListener {
            val currentLocale = resources.configuration.locales[0]
            val newLocale = if (currentLocale.language == "en") "el" else "en"
            changeAppLanguage(newLocale)
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Athens and move the camera
        val athens = LatLng(37.9715, 23.7267) // Athens coordinates
        mMap.addMarker(
            MarkerOptions()
                .position(athens)
                .title(getString(R.string.app_name))
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(athens, 15f))
    }

    private fun changeAppLanguage(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = resources.configuration
        config.setLocale(locale)
        createConfigurationContext(config)
        resources.updateConfiguration(config, resources.displayMetrics)

        // Restart activity to refresh UI
        val intent = Intent(this, MapsActivity::class.java)
        finish()
        startActivity(intent)
    }
}
