package com.example.dineout

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.example.dineout.data.*
import com.example.dineout.ui.screens.*
import com.example.dineout.ui.theme.DineOutTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var repository: DineOutRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Room database
        val database = Room.databaseBuilder(
            applicationContext,
            DineOutDatabase::class.java,
            "dineout_database"
        ).build()

        repository = DineOutRepository(database)

        setContent {
            DineOutTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    var currentRestaurant by remember { mutableStateOf<Restaurant?>(null) }
                    var favoriteRestaurants by remember { mutableStateOf(setOf<String>()) }
                    
                    // Cart state management
                    var cartItems by remember { mutableStateOf(mapOf<MenuItem, Int>()) }
                    var cartItemCount by remember { mutableStateOf(0) }
                    
                    // Order history state
                    var orderHistory by remember { mutableStateOf(listOf<Order>()) }
                    val scope = rememberCoroutineScope()
                    
                    // Load orders from database
                    LaunchedEffect(Unit) {
                        repository.getAllOrders().collect { orders ->
                            orderHistory = orders
                        }
                    }
                    
                    // Function to update cart
                    val updateCart = { item: MenuItem, quantity: Int ->
                        val currentQuantity = cartItems[item] ?: 0
                        val newQuantity = quantity
                        
                        // Update total count
                        cartItemCount = cartItemCount - currentQuantity + (if (newQuantity > 0) newQuantity else 0)
                        
                        // Update cart items
                        cartItems = if (newQuantity > 0) {
                            cartItems + (item to newQuantity)
                        } else {
                            cartItems - item
                        }
                    }

                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                onRestaurantClick = { restaurant ->
                                    currentRestaurant = restaurant
                                    navController.navigate("restaurant_detail")
                                },
                                onMapClick = {
                                    navController.navigate("map")
                                },
                                onHistoryClick = {
                                    navController.navigate("history")
                                },
                                favoriteRestaurants = favoriteRestaurants
                            )
                        }
                        composable("map") {
                            MapScreen(
                                onBackClick = { navController.popBackStack() },
                                onRestaurantClick = { restaurant ->
                                    currentRestaurant = restaurant
                                    navController.navigate("restaurant_detail")
                                },
                                favoriteRestaurants = favoriteRestaurants
                            )
                        }
                        composable("restaurant_detail") {
                            if (currentRestaurant != null) {
                                RestaurantDetailScreen(
                                    restaurant = currentRestaurant!!,
                                    onBackClick = { navController.popBackStack() },
                                    onFavoriteClick = {
                                        favoriteRestaurants = if (currentRestaurant!!.id in favoriteRestaurants) {
                                            favoriteRestaurants - currentRestaurant!!.id
                                        } else {
                                            favoriteRestaurants + currentRestaurant!!.id
                                        }
                                    },
                                    isFavorite = currentRestaurant!!.id in favoriteRestaurants,
                                    onMenuClick = {
                                        navController.navigate("menu")
                                    }
                                )
                            } else {
                                // Show a fallback UI if no restaurant is selected
                                Surface(modifier = Modifier.fillMaxSize()) {
                                    Text(
                                        text = "No restaurant selected.",
                                        style = MaterialTheme.typography.headlineMedium,
                                        modifier = Modifier.padding(32.dp)
                                    )
                                }
                            }
                        }
                        composable("menu") {
                            if (currentRestaurant != null) {
                                MenuScreen(
                                    restaurant = currentRestaurant!!,
                                    onBackClick = { navController.popBackStack() },
                                    onFavoriteClick = {
                                        favoriteRestaurants = if (currentRestaurant!!.id in favoriteRestaurants) {
                                            favoriteRestaurants - currentRestaurant!!.id
                                        } else {
                                            favoriteRestaurants + currentRestaurant!!.id
                                        }
                                    },
                                    isFavorite = currentRestaurant!!.id in favoriteRestaurants,
                                    onCartClick = {
                                        navController.navigate("cart")
                                    },
                                    cartItems = cartItems,
                                    cartItemCount = cartItemCount,
                                    onUpdateCart = updateCart
                                )
                            } else {
                                Surface(modifier = Modifier.fillMaxSize()) {
                                    Text(
                                        text = "No restaurant selected.",
                                        style = MaterialTheme.typography.headlineMedium,
                                        modifier = Modifier.padding(32.dp)
                                    )
                                }
                            }
                        }
                        composable("cart") {
                            CartScreen(
                                restaurant = currentRestaurant,
                                cartItems = cartItems,
                                onBackClick = { navController.popBackStack() },
                                onCheckoutClick = { order ->
                                    scope.launch {
                                        // Save order to database
                                        repository.insertOrder(order)
                                        
                                        // Save delivery address to recent addresses
                                        repository.addRecentAddress(order.deliveryAddress)
                                        
                                        // Clear cart after checkout
                                        cartItems = emptyMap()
                                        cartItemCount = 0
                                    }
                                },
                                onUpdateQuantity = updateCart
                            )
                        }
                        composable("history") {
                            HistoryScreen(
                                orders = orderHistory,
                                onBackClick = { navController.popBackStack() },
                                onOrderClick = { _ ->
                                    // Could navigate to order details in future
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

